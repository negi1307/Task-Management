/*
 *
 * WishList constants
 *
 */

export const FETCH_WISHLIST = 'src/WishList/FETCH_WISHLIST';
export const SET_WISHLIST_LOADING = 'src/WishList/SET_WISHLIST_LOADING';
