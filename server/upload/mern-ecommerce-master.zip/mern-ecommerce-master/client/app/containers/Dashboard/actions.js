/*
 *
 * Dashboard actions
 *
 */

import { TOGGLE_DASHBOARD_MENU } from './constants';

export const toggleDashboardMenu = () => {
  return {
    type: TOGGLE_DASHBOARD_MENU
  };
};
