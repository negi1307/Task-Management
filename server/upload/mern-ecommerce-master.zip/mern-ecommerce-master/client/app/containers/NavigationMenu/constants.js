/*
 *
 * NavigationMenu constants
 *
 */

export const DEFAULT_ACTION = 'src/NavigationMenu/DEFAULT_ACTION';
